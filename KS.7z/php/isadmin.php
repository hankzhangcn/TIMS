<?php
if($u_dep != 0)
    echo "<script>alert('您没有新增管理员的权限。'); window.location.href='login.php';</script>";
?>